import React from "react";

export default function Upload() {
  return <div className="Upload">Happy Job Apply.</div>;
}
