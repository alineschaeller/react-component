import React from "react";
import { ApplicationForm } from "./ApplicationForm";

function App() {
  return <ApplicationForm />;
}

export default App;
