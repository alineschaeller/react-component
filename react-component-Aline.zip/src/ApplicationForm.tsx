import React from "react";
import styles from "./ApplicationForm.module.css";

interface Props {}

export const ApplicationForm = (props: Props) => (
  <div className={styles.Form}>
    <h2>Apply for your dream job</h2>
    <div className={styles.item}>
      <label htmlFor="name"></label>
      <input type="name" name="name" placeholder="Name"></input>
    </div>
    <div className={styles.item}>
      <label htmlFor="email"></label>
      <input type="email" name="email" placeholder="Email"></input>
    </div>

    <div className={styles.footer}>
      <p>
        <a href="">Sign in with Linkedin</a>
      </p>
      <p>
        <a href="">Sign in with Google</a>
      </p>
    </div>
    <div className={styles.item}>
      <input type="submit" className={styles.button} value="Apply"></input>
    </div>
    <div className={styles.upload}> Drag and drop your files here </div>
  </div>
);
