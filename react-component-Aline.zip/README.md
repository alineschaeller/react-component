# optilyz design challenge

You can use this template repository for the design challenge.
It is based on [Create React App](https://github.com/facebook/create-react-app), 
but simplified a bit so you can focus on writing a simple, presentational
component. There is no need to make the component interactive or
add any other additional functionality to it.

## Available Scripts

In the project directory, you can run  `npm start`to run the app in the development mode.
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Deployment

To make reviewing easier for us, the application will automatically be deployed 
to GitHub Pages.
